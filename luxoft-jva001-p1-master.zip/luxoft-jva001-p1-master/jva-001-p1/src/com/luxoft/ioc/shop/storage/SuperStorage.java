package com.luxoft.ioc.shop.storage;

public class SuperStorage extends StorageServiceImpl
{
}

package com.luxoft.ioc.shop.bl;


import com.luxoft.ioc.shop.Product;

public interface StorageService
{

    void store(Product p);
}

package com.luxoft.jva001p1.animals;

public class Wolf extends AbstractAnimal
{
    @Override
    public void voice()
    {
        System.out.println("woooooooo....");
    }
}

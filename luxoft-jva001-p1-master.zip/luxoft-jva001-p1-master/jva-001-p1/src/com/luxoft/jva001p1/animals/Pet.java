package com.luxoft.jva001p1.animals;

public interface Pet
{
    String getAddress();

    String getName();
}

package com.luxoft.jva001p1.animals;

public abstract class AbstractAnimal
{
    public abstract void voice();
}

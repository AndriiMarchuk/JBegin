package com.luxoft.jva001p1.generics.xtasks.bankapp.utils;

import com.luxoft.jva001p1.generics.xtasks.bankapp.domain.Client;

public interface ClientRegistrationListener
{
    void onClientAdded(Client client);
}

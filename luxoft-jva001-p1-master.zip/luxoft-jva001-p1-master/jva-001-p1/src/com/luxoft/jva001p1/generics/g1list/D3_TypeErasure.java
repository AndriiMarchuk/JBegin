package com.luxoft.jva001p1.generics.g1list;

public class D3_TypeErasure<T>
{
//    public boolean equals(T obj)
//    {
//        return super.equals(obj);
//    }
}


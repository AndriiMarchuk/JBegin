package com.luxoft.jva001p1.generics.g9restrictions;

public class StaticRestrictions<T>
{
    // will not compile
//    private static T instance;

    // will not compile
//    public static T getInstance()
//    {
//        return null;
//    }
}

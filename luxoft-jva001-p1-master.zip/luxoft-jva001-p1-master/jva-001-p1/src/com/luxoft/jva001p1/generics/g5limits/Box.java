package com.luxoft.jva001p1.generics.g5limits;

import java.io.Serializable;

public class Box<T extends Number & Comparable & Serializable>
{
}

package com.luxoft.jva001p1.generics.g1list;

public class D4_TypeErasure<String>
{
    public boolean equals(Object obj)
    {
        return super.equals(obj);
    }

//    public boolean equals(String obj)
//    {
//        return super.equals(obj);
//    }
}


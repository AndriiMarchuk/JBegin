package com.luxoft.jva001p1.generics.xtasks.bankapp.exceptions;

public class BankException extends Exception
{
    private static final long serialVersionUID = 3214520997410884213L;

    public BankException(String message)
    {
        super(message);
    }
}

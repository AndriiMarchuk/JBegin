package com.luxoft.jva001p1.generics;

import java.util.ArrayList;
import java.util.List;

public class ForPres
{

    public static void main(String[] args)
    {


    }
}


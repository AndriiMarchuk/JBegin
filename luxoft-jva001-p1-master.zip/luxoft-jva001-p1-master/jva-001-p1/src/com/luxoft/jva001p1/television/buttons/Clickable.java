package com.luxoft.jva001p1.television.buttons;

public interface Clickable
{
    void click();
}

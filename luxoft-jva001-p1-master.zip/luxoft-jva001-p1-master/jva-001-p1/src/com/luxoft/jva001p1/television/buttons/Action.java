package com.luxoft.jva001p1.television.buttons;

public enum Action
{
    ON, OFF, NEXT, PREV;
}

package com.luxoft.jva001p1.basics.part3;

public class E3_for_each_Loop
{
    public static void main(String[] args)
    {
        int[] numbers = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9};

        for (int n : numbers)
        {
            System.out.println(n);
        }
    }
}

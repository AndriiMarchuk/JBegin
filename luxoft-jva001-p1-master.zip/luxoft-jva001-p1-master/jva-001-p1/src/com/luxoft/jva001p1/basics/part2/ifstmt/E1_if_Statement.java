package com.luxoft.jva001p1.basics.part2.ifstmt;

public class E1_if_Statement
{
    public static void main(String[] args)
    {
        int a = 10;

        if (a % 2 == 0)
        {
            a *= 2;
        }

        System.out.println(a);
    }
}

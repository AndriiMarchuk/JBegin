package com.luxoft.jva001p1.inners.i5animals;

public interface Pet
{
    String getName();

    void beFriendly();
}

package com.luxoft.jva001p1.inners.i3anonymus.filter;

public interface Filter
{
    boolean filter(String s);
}

package com.luxoft.jva001p1.inners.i3anonymus.superman;

public interface Flier
{
    void fly();
}

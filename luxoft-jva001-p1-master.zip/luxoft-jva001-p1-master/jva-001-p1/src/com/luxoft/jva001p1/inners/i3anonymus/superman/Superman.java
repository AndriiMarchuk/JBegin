package com.luxoft.jva001p1.inners.i3anonymus.superman;

public class Superman implements Flier
{
    @Override
    public void fly()
    {
        System.out.println("Uaaaaah...");
    }
}

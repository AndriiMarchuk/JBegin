package com.luxoft.jva001p1.p0numbers;

public class T0_Output
{

    public static void main(String[] args)
    {
        System.out.println(10 + 5 / 2);
    }
}

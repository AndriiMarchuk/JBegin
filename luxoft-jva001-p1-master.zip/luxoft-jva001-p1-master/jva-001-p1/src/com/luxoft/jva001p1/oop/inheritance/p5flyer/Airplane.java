package com.luxoft.jva001p1.oop.inheritance.p5flyer;

public class Airplane implements Flyer
{
    @Override
    public void takeOff()
    {

    }

    @Override
    public void land()
    {

    }

    @Override
    public void fly()
    {

    }
}

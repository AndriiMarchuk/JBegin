package com.luxoft.jva001p1.oop.inheritance.p8bird;

public abstract class Animal
{
    void eat()
    {

    }
}

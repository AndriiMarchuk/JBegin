package com.luxoft.jva001p1.oop.inheritance;

public class StackRef
{
    public StackRef(int foo)
    {
    }

}

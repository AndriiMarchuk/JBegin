package com.luxoft.jva001p1.oop.inheritance.p3animals;


public class Wolf extends Animal
{
    @Override
    public void makeNoise()
    {
        System.out.println("woooo...");
    }
}

package com.luxoft.jva001p1.oop.inheritance.p5flyer;

public interface Flyer
{
    void takeOff();

    void land();

    void fly();
}

package com.luxoft.jva001p1.oop.inheritance.p8bird;

public interface Flyer
{
    void takeOff();

    void land();

    void fly();
}

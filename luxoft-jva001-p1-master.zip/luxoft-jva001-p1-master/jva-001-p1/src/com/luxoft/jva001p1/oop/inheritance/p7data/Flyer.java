package com.luxoft.jva001p1.oop.inheritance.p7data;

public interface Flyer
{
    public static final int WINGS = 2;

    // This equals:
    void fly();
}

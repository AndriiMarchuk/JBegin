package com.luxoft.jva001p1.oop.inheritance.p1animals;


public class Wolf extends Animal
{

}

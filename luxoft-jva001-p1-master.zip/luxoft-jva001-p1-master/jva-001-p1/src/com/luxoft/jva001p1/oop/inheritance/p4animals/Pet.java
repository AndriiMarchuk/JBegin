package com.luxoft.jva001p1.oop.inheritance.p4animals;

public interface Pet
{
    void beFriendly();

    void play();
}

package com.luxoft.jva001p1.oop;

import java.util.*;

public class E1_DatePrinter
{
    public static void main(String[] args)
    {
        Date currentDate = new Date();
        System.out.println(currentDate);
    }
}

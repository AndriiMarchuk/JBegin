package com.luxoft.jva001p1.oop.inheritance.p8bird;

public class Bird extends Animal implements Flyer
{

    @Override
    public void takeOff()
    {

    }

    @Override
    void eat()
    {
        super.eat();
    }

    @Override
    public void land()
    {

    }

    @Override
    public void fly()
    {

    }

    public void buildNest()
    {

    }

    public void layEggs()
    {

    }
}

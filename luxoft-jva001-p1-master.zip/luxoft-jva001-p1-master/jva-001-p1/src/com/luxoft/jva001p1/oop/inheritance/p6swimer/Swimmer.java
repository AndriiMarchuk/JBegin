package com.luxoft.jva001p1.oop.inheritance.p6swimer;

public interface Swimmer
{
    void swim();
}

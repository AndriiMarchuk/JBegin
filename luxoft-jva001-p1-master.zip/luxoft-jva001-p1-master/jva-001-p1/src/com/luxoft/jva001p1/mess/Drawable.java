package com.luxoft.jva001p1.mess;

import java.awt.Graphics;

public interface Drawable
{
    void draw(Graphics graphics);
}

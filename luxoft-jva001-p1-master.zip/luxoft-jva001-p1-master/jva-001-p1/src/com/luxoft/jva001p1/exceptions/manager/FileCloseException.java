package com.luxoft.jva001p1.exceptions.manager;

public class FileCloseException extends Exception
{
}

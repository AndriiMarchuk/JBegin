package com.luxoft.jva001p1.exceptions.person;

public class Person
{
    public void sendMessage(String msg)
    {

    }
}

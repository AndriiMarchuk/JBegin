package com.luxoft.jva001p1.demos;

import com.luxoft.jva001p1.oop.inheritance.p7data.Flyer;

public class Demo
{
    public static void main(String[] args)
    {
        System.out.println(Flyer.WINGS);
    }

}

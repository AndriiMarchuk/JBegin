package com.luxoft.oop.inheritance.p1animals;


public class Wolf extends Animal
{

}

package com.luxoft.oop.enums;

public enum LightState
{
    RED, YELLOW, GREEN;
}

//    public static void main(String[] args)
//    {
//        switch (nextTrafficLight.getState())
//        {
//        case LightState.RED; stop(); break;
//        case LightState.YELLOW; floorIt(); break;
//        case LightState.GREEN; go(); break;
//        }
//    }

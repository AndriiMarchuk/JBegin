package com.luxoft.oop.inheritance.p6swimer;

public interface Flyer
{
    void fly();
}

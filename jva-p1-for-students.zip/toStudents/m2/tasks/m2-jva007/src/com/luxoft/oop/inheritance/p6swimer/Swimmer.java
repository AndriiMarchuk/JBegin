package com.luxoft.oop.inheritance.p6swimer;

public interface Swimmer
{
    void swim();
}

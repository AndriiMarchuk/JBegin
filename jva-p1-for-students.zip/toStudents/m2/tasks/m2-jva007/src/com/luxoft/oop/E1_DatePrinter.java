package com.luxoft.oop;

import java.util.Date;

public class E1_DatePrinter
{
    public static void main(String[] args)
    {
        Date currentDate = new Date();
        System.out.println(currentDate);
    }
}

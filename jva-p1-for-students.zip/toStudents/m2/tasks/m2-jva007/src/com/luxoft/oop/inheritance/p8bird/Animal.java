package com.luxoft.oop.inheritance.p8bird;

public abstract class Animal
{
    void eat()
    {

    }
}

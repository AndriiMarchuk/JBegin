package com.luxoft.oop.inheritance;

public class StackRef
{
    public StackRef(int foo)
    {
    }

}

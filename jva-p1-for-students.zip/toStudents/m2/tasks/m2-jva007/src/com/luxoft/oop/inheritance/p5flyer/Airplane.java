package com.luxoft.oop.inheritance.p5flyer;

public class Airplane implements Flyer
{
    @Override
    public void takeOff()
    {

    }

    @Override
    public void land()
    {

    }

    @Override
    public void fly()
    {

    }
}

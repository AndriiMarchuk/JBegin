package com.luxoft.oop.inheritance.p6swimer;

public class Duck implements Flyer, Swimmer
{
    @Override
    public void fly()
    {

    }

    @Override
    public void swim()
    {

    }
}

package com.luxoft.oop.inheritance.p5flyer;

public interface Flyer
{
    void takeOff();

    void land();

    void fly();
}

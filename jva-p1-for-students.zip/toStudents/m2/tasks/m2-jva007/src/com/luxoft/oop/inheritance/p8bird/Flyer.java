package com.luxoft.oop.inheritance.p8bird;

public interface Flyer
{
    void takeOff();

    void land();

    void fly();
}

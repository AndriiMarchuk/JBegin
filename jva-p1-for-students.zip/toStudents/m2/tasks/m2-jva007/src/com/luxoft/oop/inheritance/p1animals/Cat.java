package com.luxoft.oop.inheritance.p1animals;

public class Cat extends Animal
{
    private String name;

    public Cat()
    {
    }

    public String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }
}

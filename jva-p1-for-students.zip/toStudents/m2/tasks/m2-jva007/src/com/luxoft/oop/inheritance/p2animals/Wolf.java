package com.luxoft.oop.inheritance.p2animals;

public class Wolf extends Animal
{
    @Override
    public void makeNoise()
    {
        System.out.println("woooo...");
    }
}

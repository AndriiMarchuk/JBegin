package com.luxoft.oop;

public class E0_MyFirstApp
{
    public static void main(String[] args)
    {
        System.out.println("I Rule!");
        System.out.println("The World");
    }
}

package com.luxoft.basics.part1.xtasks;

public class T1_BattleField
{
    public static void main(String[] args)
    {
        System.out.println("  | A B C D E F G H I");
        System.out.println("--|------------------");

        System.out.println("1 | B B B B B B B B B");
        System.out.println("2 |");
        System.out.println("3 | B B   B B B   B B");
        System.out.println("4 | B B   B B B   B B");
        System.out.println("5 | B B   B B B   B B");
        System.out.println("6 | B B B   B B     B");
        System.out.println("7 | B B B   B B     B");
        System.out.println("8 | B B B   B B     B");
        System.out.println("9 | B B B T E B B   B");
    }
}

package com.luxoft.basics.part2.loops;

public class E4_while_Loop
{
    public static void main(String[] args)
    {
        int counter = 0;

        while (counter < 10)
        {
            System.out.println(counter++);
        }
    }
}

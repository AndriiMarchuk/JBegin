package com.luxoft.basics.part1.numbers;

public class E2_RealNumbers
{
    public static void main(String[] args)
    {
        double randomPrice = 459.98;

        double youCanAlsoDoTheMathHere = 34.9 + 98 * 6;

        float iNeedFloat = 4.05f;

        System.out.println(Double.MIN_VALUE);
        System.out.println(Double.MAX_VALUE);
    }
}

package com.luxoft.basics;

public class FileStructure
{
    public static void main(String[] args)
    {
        // comments in Java start with double slash at the start of the line

        // your code here between { }
    }
}

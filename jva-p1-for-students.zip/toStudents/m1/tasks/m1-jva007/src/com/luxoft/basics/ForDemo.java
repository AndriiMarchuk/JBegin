package com.luxoft.basics;

public class ForDemo
{

    public static void main(String[] args)
    {
        System.out.println("Max + 1: " + (Integer.MAX_VALUE + 1));
    }
}

package com.luxoft.basics.part1.text;

public class E8_Char
{
    public static void main(String[] args)
    {
        char a = 'a';
        System.out.println(a);

        char A = 65;
        System.out.println(A);

        System.out.println();
        System.out.print("Char range: ");
        System.out.println((int) Character.MIN_VALUE + " - " + (int) Character.MAX_VALUE);
    }
}

package com.luxoft.basics.part1.text;

public class E6_StringLength
{
    public static void main(String[] args)
    {
        String name = "Alexandra";

        int length = name.length();

        System.out.println(name + " contains " + length + " letters.");
    }
}

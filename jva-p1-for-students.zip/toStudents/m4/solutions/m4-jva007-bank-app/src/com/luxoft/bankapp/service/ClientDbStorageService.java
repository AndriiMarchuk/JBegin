package com.luxoft.bankapp.service;

import com.luxoft.bankapp.domain.Client;

import java.util.List;

public class ClientDbStorageService implements StorageService<Client>
{

    @Override
    public Client store(Client object)
    {
        return null;
    }

    @Override
    public Client getById(int id)
    {
        return null;
    }

    @Override
    public Client update(Client toUpdate)
    {
        return null;
    }

    @Override
    public void delete(Client object)
    {

    }

    @Override
    public List<Client> getAll()
    {
        return null;
    }
}

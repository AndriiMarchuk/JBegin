package com.luxoft.bankapp.utils;

import com.luxoft.bankapp.domain.Client;

public interface ClientRegistrationListener
{
    void onClientAdded(Client client);
}

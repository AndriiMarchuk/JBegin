package com.luxoft.bankapp.exceptions;

public class BankException extends Exception
{
    private static final long serialVersionUID = 3214520997410884213L;

    public BankException(String message)
    {
        super(message);
    }
}

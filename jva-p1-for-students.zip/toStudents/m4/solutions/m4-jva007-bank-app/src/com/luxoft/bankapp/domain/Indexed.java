package com.luxoft.bankapp.domain;

public abstract class Indexed
{
    private int id;

    public int getId()
    {
        return id;
    }

    public void setId(int id)
    {
        this.id = id;
    }
}
